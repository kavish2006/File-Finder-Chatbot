# LFS File Search Chatbot — HTML + Python

## Architecture

Browser:
HTML + CSS + JavaScript
        ↓
Python Flask
        ↓
Local File System / Shared LFS
        ↓
File path + Open File

## Setup

1. Install Python 3.10+.

2. Open Command Prompt in this folder.

3. Install Flask:

```bash
pip install -r requirements.txt
```

4. Open `app.py`.

5. Change:

```python
LFS_ROOT = r"C:\LFS"
```

to your actual LFS folder.

Examples:

```python
LFS_ROOT = r"D:\LFS"
```

or a mapped network drive:

```python
LFS_ROOT = r"Z:\CompanyLFS"
```

6. Start:

```bash
python app.py
```

7. Open in your browser:

```text
http://127.0.0.1:5000
```

## Expected folder structure

For the filters to work automatically, a recommended structure is:

```text
C:\LFS
│
├── Case studies
│   ├── Playwright
│   ├── Python
│   └── Selenium
│
├── Demo videos
│   ├── Playwright
│   └── Selenium
│
├── POC
│   ├── Python
│   ├── Tensai-NG
│   └── Amigo
│
├── RFP
│
├── Effort estimation
│
├── Use cases
│
└── Others
```

The backend searches the file name and checks the complete path for the selected category and technology.

## Open File

The `Open File` button is handled by Python using Windows `os.startfile()`.
It opens the selected file in its default application.

Therefore, the Flask server must run on a Windows machine that has access to the LFS.

## Next upgrade for a large enterprise LFS

For an LFS containing tens of thousands/millions of files, replace live recursive scanning with:

1. Initial LFS indexing
2. SQLite/PostgreSQL metadata database
3. File name + category + technology indexes
4. Optional document-content indexing
5. Background index refresh
6. Chatbot-style natural-language search

This will make searches much faster than scanning the LFS on every request.
