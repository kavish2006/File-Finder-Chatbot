const fileName = document.getElementById("fileName");
const searchButton = document.getElementById("searchButton");
const resultsSection = document.getElementById("resultsSection");
const resultsContainer = document.getElementById("results");
const resultCount = document.getElementById("resultCount");
const message = document.getElementById("message");

document.querySelectorAll(".option input").forEach(input => {
    input.addEventListener("change", () => {
        const group = input.name;

        document.querySelectorAll(`input[name="${group}"]`).forEach(item => {
            item.closest(".option").classList.toggle("selected", item.checked);
        });
    });
});

function selectedValue(name) {
    const selected = document.querySelector(`input[name="${name}"]:checked`);
    return selected ? selected.value : "";
}

function showMessage(text) {
    message.textContent = text;
    message.classList.remove("hidden");
}

function hideMessage() {
    message.classList.add("hidden");
}

function renderResults(results) {
    resultsContainer.innerHTML = "";

    results.forEach((file, index) => {
        const card = document.createElement("div");
        card.className = "result-card";

        card.innerHTML = `
            <div class="file-info">
                <div class="file-name">${index + 1}. ${escapeHtml(file.name)}</div>
                <div class="file-path">${escapeHtml(file.path)}</div>
                <span class="file-type">${escapeHtml(file.extension)}</span>
            </div>
            <button class="open-btn">📂 Open File</button>
        `;

        card.querySelector(".open-btn").addEventListener("click", () => {
            openFile(file.path);
        });

        resultsContainer.appendChild(card);
    });
}

async function searchFiles() {
    const name = fileName.value.trim();

    hideMessage();

    if (!name) {
        showMessage("Please enter a file name.");
        return;
    }

    searchButton.disabled = true;
    searchButton.textContent = "Searching...";

    try {
        const response = await fetch("/search", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                file_name: name,
                category: selectedValue("category"),
                technology: selectedValue("technology")
            })
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            resultsSection.classList.add("hidden");
            showMessage(data.message || "Search failed.");
            return;
        }

        resultsSection.classList.remove("hidden");
        resultCount.textContent = `${data.count} file${data.count === 1 ? "" : "s"}`;

        if (data.count === 0) {
            resultsContainer.innerHTML = "";
            showMessage(
                "No matching files found. Try a partial file name or change the filters."
            );
            return;
        }

        renderResults(data.results);

    } catch (error) {
        resultsSection.classList.add("hidden");
        showMessage("Could not connect to the Python backend.");
    } finally {
        searchButton.disabled = false;
        searchButton.textContent = "Search";
    }
}

async function openFile(path) {
    try {
        const response = await fetch("/open", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({path})
        });

        const data = await response.json();

        if (!data.success) {
            showMessage(data.message || "Could not open the file.");
        }
    } catch (error) {
        showMessage("Could not connect to the Python backend.");
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

searchButton.addEventListener("click", searchFiles);

fileName.addEventListener("keydown", event => {
    if (event.key === "Enter") {
        searchFiles();
    }
});
