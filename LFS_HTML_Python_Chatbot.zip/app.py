from flask import Flask, render_template, request, jsonify
from pathlib import Path
import os
import subprocess

app = Flask(__name__)

# CHANGE THIS TO YOUR LFS ROOT FOLDER
LFS_ROOT = r"C:\LFS"

CATEGORIES = [
    "Case studies",
    "Demo videos",
    "POC",
    "RFP",
    "Effort estimation",
    "Use cases",
    "Others"
]

TECHNOLOGIES = [
    "Playwright",
    "Tensai-NG",
    "Python",
    "Selenium",
    "ATOP TALOS",
    "Amigo",
    "Others"
]

def normalize(text):
    return " ".join(text.lower().replace("_", " ").replace("-", " ").split())

def matches_filter(path, value):
    return normalize(value) in normalize(str(path))

def search_lfs(file_name, category, technology):
    root = Path(LFS_ROOT)

    if not root.exists():
        return None, f"LFS folder does not exist: {root}"

    query = normalize(file_name)
    results = []

    try:
        for path in root.rglob("*"):
            if not path.is_file():
                continue

            if path.name.startswith("~$"):
                continue

            if query and query not in normalize(path.name):
                continue

            if category != "All categories" and not matches_filter(path, category):
                continue

            if technology != "All technologies" and not matches_filter(path, technology):
                continue

            results.append({
                "name": path.name,
                "path": str(path),
                "extension": path.suffix.upper() or "FILE"
            })

    except PermissionError:
        pass

    results.sort(key=lambda x: x["name"].lower())
    return results, None

@app.route("/")
def index():
    return render_template(
        "index.html",
        categories=CATEGORIES,
        technologies=TECHNOLOGIES
    )

@app.post("/search")
def search():
    data = request.get_json(silent=True) or {}

    file_name = data.get("file_name", "").strip()
    category = data.get("category", "All categories")
    technology = data.get("technology", "All technologies")

    if not file_name:
        return jsonify({
            "success": False,
            "message": "Please enter a file name."
        }), 400

    results, error = search_lfs(file_name, category, technology)

    if error:
        return jsonify({
            "success": False,
            "message": error
        }), 500

    return jsonify({
        "success": True,
        "count": len(results),
        "results": results
    })

@app.post("/open")
def open_file():
    data = request.get_json(silent=True) or {}
    file_path = data.get("path", "")

    if not file_path:
        return jsonify({"success": False, "message": "No file path supplied."}), 400

    path = Path(file_path)

    # Security: only permit files inside the configured LFS root.
    try:
        root_resolved = Path(LFS_ROOT).resolve()
        file_resolved = path.resolve()

        if root_resolved != file_resolved and root_resolved not in file_resolved.parents:
            return jsonify({
                "success": False,
                "message": "Access denied: file is outside the configured LFS."
            }), 403

        if not file_resolved.exists() or not file_resolved.is_file():
            return jsonify({
                "success": False,
                "message": "File does not exist."
            }), 404

        os.startfile(str(file_resolved))  # Windows
        return jsonify({"success": True})

    except Exception as exc:
        return jsonify({
            "success": False,
            "message": str(exc)
        }), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
